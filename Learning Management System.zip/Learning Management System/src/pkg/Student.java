package pkg;

import java.util.ArrayList;
import java.util.Observable;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

public class Student extends Person
{
	
	
	ArrayList<Course> courses=new ArrayList<Course>();
	 VBox vboxx=new VBox(3);
	Label label=new Label();
	private String cname;
	private String coursetimetable;
	 int present,absent;
	 CheckBox markatt=new CheckBox();
	
	public String getCoursename() {
		return cname;
	}
	public void setCoursename(String coursename) {
		this.cname = coursename;
	}
	public String getCoursetimetable() {
		return coursetimetable;
	}
	public void setCoursetimetable(String coursetimetable) {
		this.coursetimetable = coursetimetable;
	}
	public Student(String name, String email, String password, String gender, String birthday, String phonenumber,String campus, String department,String type) {
		super();
		this.name = name;
		this.email = email;
		this.password = password;
		this.gender = gender;
		this.birthday = birthday;
		this.phonenumber = phonenumber;
		this.campus = campus;
		this.department = department;
		present=0;
		absent=0;
	}
	Student()
	{
		this.name="";
		this.email="";
		this.password="";
		this.gender="";
		this.birthday="";
		this.phonenumber ="";
		this.campus = "EDC TOWER";
		this.department = "";
		this.cname="";
		this.coursetimetable="";
		
	}
	
	public int getPresent() {
		return present;
	}
	public void setPresent(int present) {
		this.present = present;
	}
	public int getAbsent() {
		return absent;
	}
	public void setAbsent(int absent) {
		this.absent = absent;
	}
	
	
	
	
	 

	
}
