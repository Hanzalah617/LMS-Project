package pkg;

public class Person 
{
 protected String name,email,password,gender,birthday,phonenumber,campus,department,type;






public Person(String name, String email, String password, String gender, String birthday, String phonenumber,String campus, String department,String type) {
	super();
	this.name = name;
	this.email = email;
	this.password = password;
	this.gender = gender;
	this.birthday = birthday;
	this.phonenumber = phonenumber;
	this.campus = campus;
	this.department = department;
	this.type=type;
}

public Person()
{
	this.name="";
	this.email="";
	this.password="";
	this.gender="";
	this.birthday="";
	this.phonenumber ="";
	this.campus = "EDC TOWER";
	this.department = "";
	this.type="";
}

public String getPhonenumber() {
	return phonenumber;
}
public void setPhonenumber(String phonenumber) {
	this.phonenumber = phonenumber;
}
public String getCampus() {
	return campus;
}
public void setCampus(String campus) {
	this.campus = campus;
}
public String getDepartment() {
	return department;
}
public void setDepartment(String department) {
	this.department = department;
}
public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}

public String getGender() {
	return gender;
}

public void setGender(String gender) {
	this.gender = gender;
}

public String getBirthday() {
	return birthday;
}

public void setBirthday(String birthday) {
	this.birthday = birthday;
}

public String getType() {
	return type;
}

public void setType(String type) {
	this.type = type;
}

}
